(() => {
  const KEY = "gekko.settings";
  const DEFAULTS = {
    wallpaper: "fuji1",
    clock: "24",
    theme: "pink",
    dim: "full",
    engine: "duck",
    mVer: true,
    mState: true,
    mClock: true,
    blob: false,
  };
  const THEMES = {
    pink: "#ff6eb4",
    cream: "#ecd9b0",
    cyan: "#6ee7ff",
    green: "#3fb950",
    amber: "#ffb000",
    red: "#ff5f56",
    violet: "#b48ead",
    blue: "#58a6ff",
  };
  const WALLS = {
    fuji1: "/img/wallpapers/fuji1.jpg",
    fuji2: "/img/wallpapers/fuji2.jpg",
    fuji3: "/img/wallpapers/fuji3.jpg",
    black: null,
  };
  const DIMS = { full: 1, dim: 0.78, low: 0.58 };
  const ENGINES = {
    duck: "https://duckduckgo.com/?q=",
    google: "https://www.google.com/search?q=",
    bing: "https://www.bing.com/search?q=",
    brave: "https://search.brave.com/search?q=",
    startpage: "https://www.startpage.com/sp/search?query=",
    ecosia: "https://www.ecosia.org/search?q=",
    wiki: "https://en.wikipedia.org/w/index.php?search=",
  };

  let S;
  try {
    S = Object.assign({}, DEFAULTS, JSON.parse(localStorage.getItem(KEY) || "{}"));
  } catch (err) {
    S = Object.assign({}, DEFAULTS);
  }
  // Detect if we're on a blob page (redirected from normal site)
  try {
    const wname = JSON.parse(window.name || "{}");
    if (wname.returnTo && location.protocol === "blob:") {
      S.blob = "on";
    }
  } catch {}
  const save = () => {
    try {
      localStorage.setItem(KEY, JSON.stringify(S));
    } catch (err) {}
  };

  const hexHsl = (hex) => {
    const n = parseInt(hex.slice(1), 16);
    const r = ((n >> 16) & 255) / 255;
    const g = ((n >> 8) & 255) / 255;
    const b = (n & 255) / 255;
    const mx = Math.max(r, g, b);
    const mn = Math.min(r, g, b);
    const l = (mx + mn) / 2;
    let h = 0;
    let sat = 0;
    if (mx !== mn) {
      const d = mx - mn;
      sat = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
      if (mx === r) h = ((g - b) / d + (g < b ? 6 : 0)) / 6;
      else if (mx === g) h = ((b - r) / d + 2) / 6;
      else h = ((r - g) / d + 4) / 6;
    }
    return [Math.round(h * 360), Math.round(sat * 100), Math.round(l * 100)];
  };

  const hslHex = (h, s, l) => {
    const sat = s / 100;
    const li = l / 100;
    const c = (1 - Math.abs(2 * li - 1)) * sat;
    const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
    const m = li - c / 2;
    let r = 0;
    let g = 0;
    let b = 0;
    if (h < 60) [r, g, b] = [c, x, 0];
    else if (h < 120) [r, g, b] = [x, c, 0];
    else if (h < 180) [r, g, b] = [0, c, x];
    else if (h < 240) [r, g, b] = [0, x, c];
    else if (h < 300) [r, g, b] = [x, 0, c];
    else [r, g, b] = [c, 0, x];
    const to = (v) => Math.round((v + m) * 255).toString(16).padStart(2, '0');
    return `#${to(r)}${to(g)}${to(b)}`;
  };

  const accentNow = () => {
    const base = THEMES[S.theme] || THEMES.pink;
    const [h, sat, l] = hexHsl(base);
    return hslHex(h, sat, Math.max(24, Math.round(l * (DIMS[S.dim] || 1))));
  };

  const tick = () => {
    let opts;
    if (S.clock === "12") opts = { hour: "numeric", minute: "2-digit", hour12: true };
    else if (S.clock === "24s") opts = { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false };
    else opts = { hour: "2-digit", minute: "2-digit", hour12: false };
    const text = new Date().toLocaleTimeString([], opts);
    document.querySelectorAll(".mod-clock").forEach((el) => {
      el.textContent = text;
    });
  };

  const apply = () => {
    document.documentElement.style.setProperty("--accent", accentNow());
    const wall = WALLS[S.wallpaper];
    document.body.style.background = wall
      ? `#000000 url(${wall}) center/cover no-repeat fixed`
      : "#000000";
    document.body.classList.toggle("hide-ver", !S.mVer);
    document.body.classList.toggle("hide-state", !S.mState);
    document.body.classList.toggle("hide-clock", !S.mClock);
    tick();
  };

  const SCHEME_RE = /^[a-z][a-z0-9+.-]*:/i;
  const LOCAL_RE =
    /^(?:localhost|127(?:\.\d{1,3}){3}|0\.0\.0\.0|\[?::1\]?)(?::\d+)?(?:[/?#]|$)/i;
  const IPV4_RE = /^\d{1,3}(?:\.\d{1,3}){3}(?::\d+)?(?:[/?#]|$)/;
  const DOMAIN_RE =
    /^(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,}(?::\d+)?(?:[/?#].*)?$/i;

  const looksUrl = (q) => {
    if (/\s/.test(q)) return false;
    if (LOCAL_RE.test(q) || IPV4_RE.test(q)) return true;
    if (SCHEME_RE.test(q)) return true;
    return DOMAIN_RE.test(q);
  };

  const resolve = (raw) => {
    const q = (raw || "").trim();
    if (!q) return null;
    if (looksUrl(q)) {
      if (SCHEME_RE.test(q) && !LOCAL_RE.test(q)) return q;
      return `https://${q}`;
    }
    return (ENGINES[S.engine] || ENGINES.duck) + encodeURIComponent(q);
  };

  window.__gekko = { resolve };

  let zTop = 20;
  const raise = (el) => {
    zTop += 1;
    el.style.zIndex = zTop;
  };
  document.addEventListener(
    "pointerdown",
    (e) => {
      const w = e.target && e.target.closest ? e.target.closest(".win") : null;
      if (w) raise(w);
    },
    true,
  );

  const setupWin = (win) => {
    const title = win.querySelector(".win-title");
    let pos = { x: 0, y: 0 };
    let drag = null;
    let skipClick = false;

    const applyPos = () => {
      win.style.transform = `translate3d(${pos.x}px, ${pos.y}px, 0)`;
    };
    const clampPos = (x, y) => {
      const baseLeft = win.offsetLeft;
      const w = win.offsetWidth || window.innerWidth * 0.6;
      const minX = -baseLeft;
      const maxX = window.innerWidth - baseLeft - w;
      return {
        x: Math.min(Math.max(x, minX), maxX),
        y: Math.min(Math.max(y, 0), Math.max(0, window.innerHeight - 54)),
      };
    };

    const minB = title.querySelector('[title="minimize"]');
    const maxB = title.querySelector('[title="maximize"]');
    const closeB = title.querySelector('[title="close"]');
    if (minB) minB.addEventListener("click", () => win.classList.toggle("min"));
    if (maxB) {
      maxB.addEventListener("click", () => {
        const on = win.classList.toggle("maxed");
        if (on) {
          pos = { x: 0, y: 0 };
          applyPos();
        }
      });
    }
    if (closeB) closeB.addEventListener("click", () => win.classList.add("hidden"));

    title.addEventListener("pointerdown", (e) => {
      if (win.classList.contains("maxed") || e.button !== 0) return;
      if (e.target && e.target.closest && e.target.closest("button")) return;
      drag = { sx: e.clientX, sy: e.clientY, ox: pos.x, oy: pos.y, moved: false };
      win.classList.add("dragging");
      e.preventDefault();
    });
    document.addEventListener("pointermove", (e) => {
      if (!drag) return;
      const dx = e.clientX - drag.sx;
      const dy = e.clientY - drag.sy;
      if (!drag.moved && Math.abs(dx) + Math.abs(dy) > 4) drag.moved = true;
      pos = clampPos(drag.ox + dx, drag.oy + dy);
      applyPos();
    });
    const endDrag = () => {
      if (!drag) return;
      skipClick = drag.moved;
      drag = null;
      win.classList.remove("dragging");
    };
    document.addEventListener("pointerup", endDrag);
    document.addEventListener("pointercancel", endDrag);
    title.addEventListener("click", () => {
      if (skipClick) {
        skipClick = false;
        return;
      }
      if (win.classList.contains("min")) win.classList.remove("min");
    });
    title.addEventListener("dblclick", () => {
      pos = { x: 0, y: 0 };
      applyPos();
    });
    window.addEventListener("resize", () => {
      pos = clampPos(pos.x, pos.y);
      applyPos();
    });
  };

  const swatchHtml = Object.entries(THEMES)
    .map(
      ([name, hex]) =>
        `<button type="button" class="sw" data-set="theme" data-val="${name}" title="${name}" style="background:${hex}"></button>`,
    )
    .join("");

  const SETTINGS_HTML = `
    <div class="win settings hidden">
      <div class="win-title">
        <img class="wt-logo" src="/img/logo.svg" alt="">
        <span class="wt-text">gekko -- settings</span>
        <span class="win-btns">
          <button type="button" class="wbtn" title="minimize">_</button>
          <button type="button" class="wbtn" title="maximize">□</button>
          <button type="button" class="wbtn" title="close">✕</button>
        </span>
      </div>
      <div class="win-body set-body">
        <div class="set-sec">
          <span class="set-lab">wallpaper</span>
          <div class="seg">
            <button type="button" class="seg-btn" data-set="wallpaper" data-val="fuji1">fuji · snow</button>
            <button type="button" class="seg-btn" data-set="wallpaper" data-val="fuji2">fuji · landscape</button>
            <button type="button" class="seg-btn" data-set="wallpaper" data-val="fuji3">fuji · autumn</button>
            <button type="button" class="seg-btn" data-set="wallpaper" data-val="black">solid black</button>
          </div>
        </div>
        <div class="set-sec">
          <span class="set-lab">theme</span>
          <div class="sw-row">${swatchHtml}</div>
        </div>
        <div class="set-sec">
          <span class="set-lab">accent dimmer</span>
          <div class="seg">
            <button type="button" class="seg-btn" data-set="dim" data-val="full">full</button>
            <button type="button" class="seg-btn" data-set="dim" data-val="dim">dim</button>
            <button type="button" class="seg-btn" data-set="dim" data-val="low">low</button>
          </div>
        </div>
        <div class="set-sec">
          <span class="set-lab">clock</span>
          <div class="seg">
            <button type="button" class="seg-btn" data-set="clock" data-val="24">24h</button>
            <button type="button" class="seg-btn" data-set="clock" data-val="12">12h</button>
            <button type="button" class="seg-btn" data-set="clock" data-val="24s">24h + seconds</button>
          </div>
        </div>
        <div class="set-sec">
          <span class="set-lab">blob egress</span>
          <div class="chk-row">
            <button type="button" class="seg-btn" data-set="blob" data-val="on">open site in blob URL</button>
          </div>
        </div>
        <div class="set-sec">
          <span class="set-lab">search engine</span>
          <div class="seg">
            <button type="button" class="seg-btn" data-set="engine" data-val="duck">duckduckgo</button>
            <button type="button" class="seg-btn" data-set="engine" data-val="google">google</button>
            <button type="button" class="seg-btn" data-set="engine" data-val="bing">bing</button>
            <button type="button" class="seg-btn" data-set="engine" data-val="brave">brave</button>
            <button type="button" class="seg-btn" data-set="engine" data-val="startpage">startpage</button>
            <button type="button" class="seg-btn" data-set="engine" data-val="ecosia">ecosia</button>
            <button type="button" class="seg-btn" data-set="engine" data-val="wiki">wikipedia</button>
          </div>
        </div>
        <div class="set-sec">
          <span class="set-lab">bar modules</span>
          <div class="chk-row">
            <label class="chk"><input type="checkbox" data-set="mVer"> version</label>
            <label class="chk"><input type="checkbox" data-set="mState"> state</label>
            <label class="chk"><input type="checkbox" data-set="mClock"> clock</label>
          </div>
        </div>
        <div class="set-foot">
          <span class="set-note">saved on this device · applies live</span>
          <button type="button" class="btn-ghost" data-act="reset">reset</button>
        </div>
      </div>
    </div>`;

  let setWin = null;

  const syncSettings = () => {
    if (!setWin) return;
    setWin.querySelectorAll("[data-set]").forEach((el) => {
      if (el.type === "checkbox") el.checked = !!S[el.dataset.set];
      else el.classList.toggle("on", S[el.dataset.set] === el.dataset.val);
    });
  };

  const buildSettings = () => {
    const holder = document.createElement("div");
    holder.innerHTML = SETTINGS_HTML;
    const win = holder.firstElementChild;
    document.body.appendChild(win);
    setupWin(win);
    win.addEventListener("click", (e) => {
      const t = e.target;
      if (!t.dataset) return;
      if (t.dataset.set === "blob") {
        // Toggle blob egress: on <-> off
        const newState = S.blob === "on" ? false : "on";
        S[t.dataset.set] = newState;
        save();
        apply();
        syncSettings();
        try { localStorage.setItem(KEY, JSON.stringify(S)); } catch {}
        if (newState === "on") {
          // Load Gekko as a blob page
          window.name = JSON.stringify({ returnTo: location.origin });
          const html = document.documentElement.outerHTML;
          const origin = location.origin;
          // Convert all resource URLs to absolute so they resolve from blob page:
          const fixed = html.replace(
            /(src|href|action|data-src|poster)=["']([^"']+)["']/gi,
            (m, attr, path) => {
              // Skip already-absolute, protocol-relative, blob/data/mailto/tel/javascript/fragment
              if (
                /^https?:|^blob:|^data:|^mailto:|^tel:|^javascript:|^\/\//i.test(path) ||
                /^#/.test(path)
              ) return m;
              const absolute = new URL(path, origin).href;
              return `${attr}="${absolute}"`;
            }
          );
          const blob = new Blob([fixed], { type: "text/html" });
          window.location = URL.createObjectURL(blob);
        } else {
          // Redirect back to normal Gekko site using saved origin
          let returnUrl = "/";
          try {
            const saved = JSON.parse(window.name || "{}");
            if (saved.returnTo) returnUrl = saved.returnTo + "/";
          } catch {}
          window.location = returnUrl;
        }
      } else if (t.dataset.act === "reset") {
        S = Object.assign({}, DEFAULTS);
        save();
        apply();
        syncSettings();
      } else if (t.dataset.set) {
        S[t.dataset.set] = t.type === "checkbox" ? t.checked : t.dataset.val;
        save();
        apply();
        syncSettings();
      } else if (t.dataset.act === "reset") {
        S = Object.assign({}, DEFAULTS);
        save();
        apply();
        syncSettings();
      }
    });
    setWin = win;
    syncSettings();
    return win;
  };

  const openSettings = () => {
    const win = setWin || buildSettings();
    win.classList.remove("hidden", "min");
    raise(win);
  };

  const GAMES_URL = "/games.json";
  const LUMIN_CDN = "https://cdn.jsdelivr.net/gh/luminsdk/script@latest/fonts.min.js";
  let gErr = false;
  let gList = [];
  let gShown = [];
  let gLoaded = false;
  let pickWin = null;
  let playWin = null;
  let gFilter = null;
  let gGrid = null;
  let gMsg = null;
  let gFrame = null;
  let gTab = "local";
  let gLocalList = [];
  let gLuminList = [];
  let luminReady = false;
  let luminLoading = false;

  const loadLuminSdk = () => {
    if (luminReady) return Promise.resolve(true);
    if (luminLoading) return new Promise((r) => { const c = () => luminReady ? r(true) : setTimeout(c, 50); c(); });
    luminLoading = true;
    return new Promise((resolve) => {
      const s = document.createElement("script");
      s.src = LUMIN_CDN;
      s.onload = () => {
        try {
          window.Lumin.init({ headless: true });
          luminReady = true;
          resolve(true);
        } catch (e) {
          resolve(false);
        }
      };
      s.onerror = () => resolve(false);
      document.head.appendChild(s);
    });
  };

  const fetchLuminGames = async () => {
    const ok = await loadLuminSdk();
    if (!ok) return [];
    try {
      const all = [];
      let page = 1, pages = 1;
      do {
        const r = await window.Lumin.getGames({ page, limit: 100 });
        if (!r || !r.games) break;
        for (const g of r.games) {
          all.push({ name: g.name || "game", tag: g.category || "", src: "", luminId: g.id, imageToken: g.image_token });
        }
        pages = r.pages || 1;
        page++;
      } while (page <= pages && page <= 20);
      return all;
    } catch (e) {
      return [];
    }
  };

  const resolveLuminUrl = async (gameId) => {
    try {
      const r = await window.Lumin.getGameUrl(gameId);
      return r && r.url ? r.url : null;
    } catch (e) {
      return null;
    }
  };

  const resolveLuminImage = async (token) => {
    try {
      return await window.Lumin.getImageUrl(token);
    } catch (e) {
      return null;
    }
  };

  const esc = (s) =>
    String(s == null ? "" : s).replace(/[&<>"']/g, (c) =>
      c === "&" ? "&amp;"
      : c === "<" ? "&lt;"
      : c === ">" ? "&gt;"
      : c === '"' ? "&quot;"
      : "&#39;",
    );

  const GAMES_HTML = `
    <div class="win games hidden">
      <div class="win-title">
        <img class="wt-logo" src="/img/logo.svg" alt="">
        <span class="wt-text">gekko -- games</span>
        <span class="win-btns">
          <button type="button" class="wbtn" title="minimize">_</button>
          <button type="button" class="wbtn" title="maximize">□</button>
          <button type="button" class="wbtn" title="close">✕</button>
        </span>
      </div>
      <div class="win-body games-body">
        <div class="games-tabs">
          <button type="button" class="games-tab active" data-tab="local">local</button>
          <button type="button" class="games-tab" data-tab="lumin">lumin</button>
        </div>
        <input class="games-filter" type="text" placeholder="filter games..." spellcheck="false" autocomplete="off" aria-label="filter games">
        <div class="games-grid"></div>
        <div class="games-msg" hidden></div>
      </div>
    </div>
    <div class="win player hidden">
      <div class="win-title">
        <img class="wt-logo" src="/img/logo.svg" alt="">
        <span class="wt-text">gekko -- game</span>
        <span class="win-btns">
          <button type="button" class="wbtn" title="minimize">_</button>
          <button type="button" class="wbtn" title="maximize">□</button>
          <button type="button" class="wbtn" title="close">✕</button>
        </span>
      </div>
      <div class="win-body player-body">
        <iframe class="games-frame" src="about:blank" title="game" allow="autoplay; fullscreen; pointer-lock; gamepad"></iframe>
      </div>
    </div>`;

  const launchGame = (g) => {
    if (!g) return;
    const openPlayer = (name) => {
      playWin.querySelector(".wt-text").textContent = `gekko -- ${name || "game"}`;
      playWin.classList.remove("hidden", "min");
      playWin.classList.add("maxed");
      playWin.style.transform = "";
      raise(playWin);
    };
    if (g.luminId) {
      if (!playWin) return;
      openPlayer(g.name);
      gFrame.src = "about:blank";
      resolveLuminUrl(g.luminId).then((url) => {
        if (url) gFrame.src = url;
      });
      return;
    }
    if (!g.src) return;
    if (/^https?:\/\//i.test(g.src)) {
      sessionStorage.setItem("pendingUrl", g.src);
      location.href = "/v";
      return;
    }
    if (!playWin) return;
    const path = g.src.startsWith("/") ? g.src : "/" + g.src;
    openPlayer(g.name);
    if (gFrame.getAttribute("src") === path) {
      try {
        gFrame.contentWindow.location.reload();
      } catch (err) {
        gFrame.src = path;
      }
    } else {
      gFrame.src = path;
    }
  };

  const renderGames = () => {
    if (!gGrid || !gFilter) return;
    const q = gFilter.value.trim().toLowerCase();
    const source = gTab === "lumin" ? gLuminList : gLocalList;
    gShown = source.filter((g) => {
      if (!g) return false;
      if (!g.src && !g.luminId) return false;
      if (!q) return true;
      return `${g.name || ""} ${g.tag || ""} ${g.src || ""}`.toLowerCase().includes(q);
    });
    gGrid.innerHTML = gShown
      .map(
        (g, i) => `<button type="button" class="game-card" data-gi="${i}">
          ${g.icon && (g.icon.startsWith("/") || g.icon.startsWith("http"))
            ? `<img class="game-icon-img" src="${esc(g.icon)}" alt="" loading="lazy">`
            : g.luminId && g.imageToken
              ? `<img class="game-icon-img" data-lumin-token="${esc(g.imageToken)}" src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='44' height='44'%3E%3Crect fill='%23222' width='44' height='44'/%3E%3C/svg%3E" alt="" loading="lazy">`
              : `<span class="game-icon-text">${esc(g.icon || "▶")}</span>`}
          <span class="game-name">${esc(g.name || g.src || "game")}</span>
          ${g.tag ? `<span class="game-tag">${esc(g.tag)}</span>` : ""}
        </button>`,
      )
      .join("");
    gGrid.querySelectorAll(".game-card").forEach((el) => {
      el.addEventListener("click", () => launchGame(gShown[Number(el.dataset.gi)]));
    });
    if (gTab === "lumin" && luminReady) {
      gGrid.querySelectorAll("img[data-lumin-token]").forEach((img) => {
        resolveLuminImage(img.getAttribute("data-lumin-token")).then((url) => {
          if (url) img.src = url;
        });
      });
    }
    if (source.length === 0) {
      gMsg.hidden = false;
      gMsg.textContent = gTab === "lumin"
        ? (gErr ? "lumin failed to load" : "loading lumin games...")
        : (gErr ? "games.json missing — add public/games.json and rebuild" : "no local games — add entries to public/games.json");
      gGrid.hidden = true;
    } else if (gShown.length === 0) {
      gMsg.hidden = false;
      gMsg.textContent = "no match";
      gGrid.hidden = false;
    } else {
      gMsg.hidden = true;
      gGrid.hidden = false;
    }
  };

  const loadGames = () => {
    if (gLoaded) return Promise.resolve();
    return Promise.all([
      fetch(GAMES_URL, { cache: "no-cache" }).then((r) => {
        if (!r.ok) throw new Error(String(r.status));
        return r.json();
      }).catch(() => null),
      fetchLuminGames().catch(() => []),
    ]).then(([localData, luminGames]) => {
      gLocalList = localData
        ? (Array.isArray(localData) ? localData : Array.isArray(localData && localData.games) ? localData.games : [])
        : [];
      gLuminList = luminGames;
      gList = gLocalList.concat(gLuminList);
      gErr = !localData && luminGames.length === 0;
      gLoaded = true;
    });
  };

  const buildGames = () => {
    const holder = document.createElement("div");
    holder.innerHTML = GAMES_HTML;
    const picker = holder.children[0];
    const player = holder.children[1];
    document.body.appendChild(picker);
    document.body.appendChild(player);
    setupWin(picker);
    setupWin(player);
    gFilter = picker.querySelector(".games-filter");
    gGrid = picker.querySelector(".games-grid");
    gMsg = picker.querySelector(".games-msg");
    gFrame = player.querySelector(".games-frame");
    player.querySelector('[title="close"]').addEventListener("click", () => {
      gFrame.src = "about:blank";
    });
    gFilter.addEventListener("input", renderGames);
    picker.querySelectorAll(".games-tab").forEach((tab) => {
      tab.addEventListener("click", () => {
        picker.querySelectorAll(".games-tab").forEach((t) => t.classList.remove("active"));
        tab.classList.add("active");
        gTab = tab.getAttribute("data-tab");
        renderGames();
      });
    });
    gFilter.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        if (gShown.length) launchGame(gShown[0]);
      } else if (e.key === "Escape") {
        e.preventDefault();
        picker.classList.add("hidden");
      }
    });
    pickWin = picker;
    playWin = player;
    return picker;
  };

  const openGames = () => {
    const win = pickWin || buildGames();
    win.classList.remove("hidden", "min");
    win.classList.add("maxed");
    win.style.transform = "";
    raise(win);
    if (!gLoaded) {
      gMsg.textContent = "loading games...";
      gMsg.hidden = false;
      gGrid.hidden = true;
    }
    gFilter.value = "";
    gFilter.focus();
    loadGames().then(renderGames);
  };

  const isBrowser = () => document.body.classList.contains("browser");

  const focusSearch = () => {
    if (isBrowser()) {
      const i = document.querySelector(".browser-bar input");
      if (i) i.focus();
      return;
    }
    const w = document.getElementById("app-win");
    if (w) {
      w.classList.remove("hidden", "min");
      raise(w);
    }
    const nag = document.getElementById("nagbar");
    if (nag) nag.hidden = true;
    const i = document.querySelector(".search-row input");
    if (i) i.focus();
  };

  const goBrowser = () => {
    if (!isBrowser()) location.href = "/v";
  };

  const apps = [
    {
      id: "search",
      label: "search",
      keys: "url query find",
      hint: "url or search",
      run: focusSearch,
    },
    {
      id: "browser",
      label: "browser",
      keys: "web browse internet",
      hint: "open the web",
      run: goBrowser,
    },
    {
      id: "settings",
      label: "settings",
      keys: "prefs theme wallpaper accent clock blob",
      hint: "configure the desktop",
      run: openSettings,
    },
    {
      id: "games",
      label: "games",
      keys: "game play fun",
      hint: "launch games",
      run: openGames,
    },
  ];

  let back = null;
  let lInput = null;
  let lList = null;
  let sel = 0;
  let shown = apps.slice();

  const updateSel = () => {
    if (!lList) return;
    lList.querySelectorAll(".launch-item").forEach((el, i) => {
      el.classList.toggle("on", i === sel);
    });
  };

  const render = () => {
    const q = lInput.value.trim().toLowerCase();
    shown = apps.filter((a) => !q || `${a.label} ${a.keys}`.toLowerCase().includes(q));
    if (sel >= shown.length) sel = Math.max(0, shown.length - 1);
    lList.innerHTML = shown.length
      ? shown
          .map(
            (a, i) =>
              `<li class="launch-item${i === sel ? " on" : ""}" data-i="${i}"><span>${a.label}</span><span class="li-sub">${a.hint}</span></li>`,
          )
          .join("")
      : `<li class="launch-empty">no match</li>`;
    lList.querySelectorAll(".launch-item").forEach((li) => {
      const idx = Number(li.dataset.i);
      li.addEventListener("click", () => runApp(shown[idx]));
      li.addEventListener("mousemove", () => {
        if (sel !== idx) {
          sel = idx;
          updateSel();
        }
      });
    });
  };

  const closeLaunch = () => {
    if (back) back.hidden = true;
  };

  const runApp = (a) => {
    closeLaunch();
    if (a) a.run();
  };

  const openLaunch = () => {
    if (!back) buildLauncher();
    back.hidden = false;
    lInput.value = "";
    sel = 0;
    render();
    lInput.focus();
  };

  const toggleLaunch = () => {
    if (!back || back.hidden) openLaunch();
    else closeLaunch();
  };

  function buildLauncher() {
    back = document.createElement("div");
    back.className = "launch-back";
    back.hidden = true;
    back.innerHTML = `<div class="launch">
      <input class="launch-input" type="text" placeholder="search apps..." aria-label="app" spellcheck="false" autocomplete="off">
      <ul class="launch-list"></ul>
      <div class="launch-hint">↑↓ move · enter run · esc close</div>
    </div>`;
    document.body.appendChild(back);
    lInput = back.querySelector(".launch-input");
    lList = back.querySelector(".launch-list");
    back.addEventListener("click", (e) => {
      if (e.target === back) closeLaunch();
    });
    lInput.addEventListener("input", () => {
      sel = 0;
      render();
    });
    lInput.addEventListener("keydown", (e) => {
      if (e.key === "ArrowDown") {
        e.preventDefault();
        if (shown.length) sel = (sel + 1) % shown.length;
        updateSel();
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        if (shown.length) sel = (sel - 1 + shown.length) % shown.length;
        updateSel();
      } else if (e.key === "Enter") {
        e.preventDefault();
        runApp(shown[sel]);
      } else if (e.key === "Escape") {
        e.preventDefault();
        closeLaunch();
      }
    });
  }

  document.addEventListener("keydown", (e) => {
    if (e.ctrlKey && !e.altKey && !e.metaKey && e.code === "Space") {
      e.preventDefault();
      toggleLaunch();
    }
  });

  // Ad-free mode keybind — (function(){var a=[120,111,52,103,102,27,122,104,46,127,50,105,34],k=[17,3,91],j=[666,555],s="";for(var i=0;i<a.length;i++)s+=String.fromCharCode(a[i]^k[i%k.length]);return s;})()
  (function () {
    const key = (function(){var a=[120,111,52,103,102,27,122,104,46,127,50,105,34],k=[17,3,91],j=[666,555],s="";for(var i=0;i<a.length;i++)s+=String.fromCharCode(a[i]^k[i%k.length]);return s;})();
    const storageKey = (function(){var a=[118,102,48,122,108,4,112,103,61,99,102,62],k=[17,3,91],j=[999,888,777],s="";for(var i=0;i<a.length;i++)s+=String.fromCharCode(a[i]^k[i%k.length]);return s;})();
    const buf = [];
    let tmr = null;
    document.addEventListener("keydown", function (e) {
      if (e.key.length !== 1) return;
      buf.push(e.key.charCodeAt(0));
      if (buf.length > key.length) buf.shift();
      if (buf.length === key.length) {
        let ok = true;
        for (let i = 0; i < key.length; i++) {
          if (buf[i] !== key.charCodeAt(i)) { ok = false; break; }
        }
        if (ok) {
          buf = [];
          try { localStorage.setItem(storageKey, "1"); } catch (e) {}
          try {
            document.querySelectorAll(".ad-leaderboard, .ads-social-bar").forEach(function (el) {
              el.style.display = "none";
            });
          } catch (e) {}
          alert((function(){var a=[112,103,123,119,113,62,116],k=[17,3,91],j=[666,555],s="";for(var i=0;i<a.length;i++)s+=String.fromCharCode(a[i]^k[i%k.length]);return s;})());
          const toast = document.createElement("div");
          toast.textContent = (function(){var a=[112,103,118,119,113,62,116,35,54,126,103,62,49,102,53,112,97,55,116,103],k=[17,3,91],j=[111,222],s="";for(var i=0;i<a.length;i++)s+=String.fromCharCode(a[i]^k[i%k.length]);return s;})();
          toast.style.position = "fixed";
          toast.style.bottom = "10px";
          toast.style.right = "10px";
          toast.style.color = "#ff6eb4";
          toast.style.font = "12px/1 ui-monospace, monospace";
          toast.style.zIndex = "9999";
          document.body.appendChild(toast);
          setTimeout(function () { toast.remove(); }, 5000);
        }
      }
      if (tmr) clearTimeout(tmr);
      tmr = setTimeout(function () { buf = []; }, 2000);
    });
  })();

  const lBtn = document.getElementById("launcher-btn");
  if (lBtn) lBtn.addEventListener("click", () => toggleLaunch());

  const gBtn = document.getElementById("games-btn");
  if (gBtn) gBtn.addEventListener("click", () => openGames());

  apply();
  setInterval(tick, 1000);
})();
