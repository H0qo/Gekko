const form = document.getElementById("view-search");
const viewSearch = document.getElementById('view-input')
viewPlaceholders = [
    "made by ak-kunn btw",
    "EVERYONE GET IN THE CAR!",
    "powered by rebelion",
    "WE love Gekko"
];

form.addEventListener("submit", (event) => {
    event.preventDefault();
    const url = viewSearch.value.trim();
    if (!url) return;
    sessionStorage.setItem("pendingUrl", url);
    location.href = "/v";
});

let phIndex = 0;
setInterval(() => {
    phIndex = (phIndex + 1) % viewPlaceholders.length;
    viewSearch.placeholder = viewPlaceholders[phIndex];
}, 5000);

const win = document.getElementById("app-win");
const winTitle = document.getElementById("win-title");
const nagbar = document.getElementById("nagbar");
const stateEl = document.getElementById("state");

let pos = { x: 0, y: 0 };
const apply = () => {
  win.style.transform = `translate3d(${pos.x}px, ${pos.y}px, 0)`;
};
const clamp = (x, y) => {
  const baseLeft = win.offsetLeft;
  const w = win.offsetWidth || window.innerWidth * 0.6;
  const minX = -baseLeft;
  const maxX = window.innerWidth - baseLeft - w;
  return {
    x: Math.min(Math.max(x, minX), maxX),
    y: Math.min(Math.max(y, 0), Math.max(0, window.innerHeight - 54)),
  };
};

document.getElementById("btn-min").addEventListener("click", () => {
  win.classList.toggle("min");
});
document.getElementById("btn-max").addEventListener("click", () => {
  const on = win.classList.toggle("maxed");
  if (on) {
    pos = { x: 0, y: 0 };
    apply();
  }
});
document.getElementById("btn-close").addEventListener("click", () => {
  win.classList.add("hidden");
  nagbar.hidden = false;
});
document.getElementById("btn-reopen").addEventListener("click", () => {
  win.classList.remove("hidden");
  nagbar.hidden = true;
});

let drag = null;
let skipClick = false;

winTitle.addEventListener("pointerdown", (e) => {
  if (win.classList.contains("maxed") || e.button !== 0) return;
  if (e.target && e.target.closest && e.target.closest("button")) return;
  drag = { sx: e.clientX, sy: e.clientY, ox: pos.x, oy: pos.y, moved: false };
  win.classList.add("dragging");
  e.preventDefault();
});

document.addEventListener("pointermove", (e) => {
  if (!drag) return;
  const dx = e.clientX - drag.sx;
  const dy = e.clientY - drag.sy;
  if (!drag.moved && Math.abs(dx) + Math.abs(dy) > 4) drag.moved = true;
  pos = clamp(drag.ox + dx, drag.oy + dy);
  apply();
});

const endDrag = () => {
  if (!drag) return;
  skipClick = drag.moved;
  drag = null;
  win.classList.remove("dragging");
};

document.addEventListener("pointerup", endDrag);
document.addEventListener("pointercancel", endDrag);

winTitle.addEventListener("click", () => {
  if (skipClick) {
    skipClick = false;
    return;
  }
  if (win.classList.contains("min")) win.classList.remove("min");
});

winTitle.addEventListener("dblclick", () => {
  pos = { x: 0, y: 0 };
  apply();
});

window.addEventListener("resize", () => {
  pos = clamp(pos.x, pos.y);
  apply();
});

document.querySelectorAll(".ws").forEach((el) => {
  el.addEventListener("click", () => {
    document.querySelectorAll(".ws").forEach((w) => w.classList.remove("active"));
    el.classList.add("active");
  });
});

if (stateEl) stateEl.textContent = "ready";
